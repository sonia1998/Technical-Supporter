﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-2V8VSA9;Initial Catalog=TSS;Integrated Security=True");
            showComplaints ds = new showComplaints();
            SqlDataAdapter da = new SqlDataAdapter("select  date_of_submission,date_of_resolution,assigned_to,Complaint_Type  from viewComplaints", conn);
            da.Fill(ds.viewComplaints);
            genReport rpt = new genReport();
            rpt.SetDataSource(ds);
            CrystalReportViewer1.ReportSource = rpt;
        }
    }
}